"""Shared helpers: logging, filesystem, env, checksums, etc."""

def setup_logging():
    """Configure global logging."""
    pass

def ensure_dir(path: str):
    """Ensure that a directory exists."""
    pass