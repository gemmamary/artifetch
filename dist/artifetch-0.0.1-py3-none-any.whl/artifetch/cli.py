"""CLI entry point for Artifetch."""

import argparse

def main():
    """Main command-line interface."""
    # TODO: parse args and call core.fetch
    pass

if __name__ == "__main__":
    main()